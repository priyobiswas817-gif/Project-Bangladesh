# PRIYO_CODEX — Android AI Chat App

A lightweight Kotlin Android app (Gemini-powered chat) built to compile cleanly
in **JStudio** on a mobile device with zero heavyweight dependencies.

## Project structure

```
PRIYO_CODEX/
├── build.gradle                       (root)
├── settings.gradle
├── gradle.properties
└── app/
    ├── build.gradle                   (app module — minimal deps)
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/priyocodex/app/
        │   ├── SplashActivity.kt
        │   ├── MainActivity.kt
        │   ├── ChatAdapter.kt
        │   ├── ChatMessage.kt
        │   ├── PrefsManager.kt
        │   └── GeminiClient.kt
        └── res/
            ├── layout/  (activity_splash, activity_main, item_message_user/bot, dialog_settings)
            ├── drawable/ (gradient P logo, robot face, sparkle, icons, backgrounds — all vector/XML)
            ├── anim/    (scale_fade_in.xml, fade_in_slow.xml)
            ├── values/  (colors.xml, strings.xml, themes.xml)
            └── mipmap-anydpi-v26/ (adaptive launcher icon using the same logo)
```

## How to build in JStudio

1. Copy/import the entire `PRIYO_CODEX` folder as a new project (or unzip the
   provided archive directly into JStudio's project workspace).
2. Let Gradle sync — dependencies are limited to `core-ktx`, `activity-ktx`,
   `appcompat`, `material`, `constraintlayout`, and `recyclerview`, so there is
   nothing heavy (no OkHttp/Retrofit/Firebase) to slow down or break a mobile
   Gradle sync.
3. Build → Generate APK (Debug or Release).

## First-run setup (in-app)

On first launch, after the animated splash screen, a **Setup dialog** appears
asking for:

- **Cloudflare Worker Proxy URL** — if you're routing requests through your own
  Worker (recommended if you want to hide your API key). The proxy is called
  with the same JSON body Gemini expects (`{"contents":[...]}`) and should
  return a Gemini-shaped JSON response (or a `{"reply": "..."}` /
  `{"text": "..."}` shape — both are supported by the parser).
- **Gemini API Key** — used directly if no proxy URL is set.
- **API Version** (e.g. `v1beta`) and **Model** (e.g. `gemini-2.0-flash`,
  `gemini-2.6-flash`, etc.) — fully editable text fields, so you can point the
  app at whatever current/future model string Google publishes without
  touching code.

Direct endpoint built as:
```
https://generativelanguage.googleapis.com/{version}/models/{model}:generateContent?key={apiKey}
```

All values are stored in `SharedPreferences` and can be changed anytime via
the **gear icon** in the top-right header.

## Features implemented

- ✅ Animated splash screen (scale-up + fade-in via `res/anim`)
- ✅ Gradient "P" robot logo + sparkle accents, recreated entirely as Android
  Vector Drawables (no PNG/raster assets needed)
- ✅ Header bar: **MyAI** title, `+` new chat, trash clear chat, gear settings
- ✅ Center welcome state ("WELCOME TO PRIYO_CODEX") shown when chat is empty
- ✅ Bottom input bar: attach-image button, text field, mic button, send button
- ✅ `android:windowSoftInputMode="adjustResize"` — input bar rises above the
  keyboard automatically
- ✅ Multimodal requests: text + inline Base64 image + short chat history sent
  together in one Gemini `contents` payload
- ✅ Text-to-Speech: every AI reply can be spoken aloud (auto-speaks + a speak
  button on each bot bubble)
- ✅ Speech-to-Text: mic button on the input bar fills the text field with
  recognized speech (`RecognizerIntent`)
- ✅ Networking via plain `HttpURLConnection` + `org.json` — no extra Gradle
  dependencies required

## Notes / things you may want to customize

- The vector "P" logo is a stylized recreation of the reference artwork built
  from path data + gradients — tweak `res/drawable/ic_logo_p.xml`,
  `ic_robot_face.xml`, and `ic_sparkle.xml` if you want to refine the shape.
- `usesCleartextTraffic="true"` is set for convenience during development if
  you test against a local/non-HTTPS proxy; remove it for production if you
  only call HTTPS endpoints.
- Conversation history sent to the API is capped at the last 12 turns to keep
  requests small — adjust `takeLast(12)` in `GeminiClient.kt` as needed.
