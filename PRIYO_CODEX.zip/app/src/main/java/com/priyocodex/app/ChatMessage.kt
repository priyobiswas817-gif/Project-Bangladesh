package com.priyocodex.app

/**
 * Simple data class representing one turn in the chat, either from the
 * user or from the AI ("model"). imageUri (if present) points to an
 * attached image the user sent along with the text.
 */
data class ChatMessage(
    val text: String,
    val isUser: Boolean,
    val imageUri: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
