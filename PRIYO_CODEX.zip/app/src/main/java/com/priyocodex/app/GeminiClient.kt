package com.priyocodex.app

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Lightweight network client for talking to Gemini's generateContent endpoint
 * OR a custom Cloudflare Worker proxy that forwards to it. Deliberately uses
 * only java.net.HttpURLConnection + org.json (both part of the Android SDK)
 * so no extra Gradle dependencies (like OkHttp/Retrofit) are required —
 * keeping JStudio builds fast and dependency-error-free.
 *
 * Supports multimodal requests: plain text, a URL/link embedded in text,
 * and/or an attached image (sent as inline_data base64).
 */
class GeminiClient(private val prefs: PrefsManager) {

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    interface Callback {
        fun onSuccess(reply: String)
        fun onError(message: String)
    }

    /**
     * Sends [userText] (which may contain a URL — the model reads it as plain text
     * context) plus optional [imageBitmap] and a short [history] of prior turns.
     */
    fun sendMessage(
        userText: String,
        imageBitmap: Bitmap?,
        history: List<ChatMessage>,
        callback: Callback
    ) {
        executor.execute {
            try {
                val endpoint = buildEndpointUrl()
                val body = buildRequestBody(userText, imageBitmap, history)
                val responseText = postJson(endpoint, body)
                val reply = extractReplyText(responseText)
                mainHandler.post { callback.onSuccess(reply) }
            } catch (e: Exception) {
                Log.e(TAG, "Request failed", e)
                mainHandler.post { callback.onError(e.message ?: "Unknown network error") }
            }
        }
    }

    // ---------------------------------------------------------------------
    // Endpoint construction — flexible / custom-versioned as required
    // ---------------------------------------------------------------------
    private fun buildEndpointUrl(): String {
        val proxy = prefs.proxyUrl.trim()
        if (proxy.isNotBlank()) {
            // Custom Cloudflare Worker (or any proxy) — used as-is.
            // The proxy is expected to forward the JSON body to Gemini
            // and return the same-shaped response.
            return proxy
        }

        val version = prefs.apiVersion.trim().ifBlank { "v1beta" }
        val model = prefs.model.trim().ifBlank { "gemini-2.0-flash" }
        val key = prefs.apiKey.trim()

        return "https://generativelanguage.googleapis.com/$version/models/$model:generateContent?key=$key"
    }

    // ---------------------------------------------------------------------
    // Request body construction (multimodal: text + inline image + history)
    // ---------------------------------------------------------------------
    private fun buildRequestBody(
        userText: String,
        imageBitmap: Bitmap?,
        history: List<ChatMessage>
    ): String {
        val contents = JSONArray()

        // Include a short rolling history so the model has conversational context.
        for (msg in history.takeLast(12)) {
            val turn = JSONObject()
            turn.put("role", if (msg.isUser) "user" else "model")
            val parts = JSONArray()
            parts.put(JSONObject().put("text", msg.text))
            turn.put("parts", parts)
            contents.put(turn)
        }

        // Current user turn (text + optional image)
        val currentParts = JSONArray()
        if (userText.isNotBlank()) {
            currentParts.put(JSONObject().put("text", userText))
        }
        if (imageBitmap != null) {
            val base64Image = bitmapToBase64(imageBitmap)
            val inlineData = JSONObject()
                .put("mimeType", "image/jpeg")
                .put("data", base64Image)
            currentParts.put(JSONObject().put("inlineData", inlineData))
        }

        val currentTurn = JSONObject()
        currentTurn.put("role", "user")
        currentTurn.put("parts", currentParts)
        contents.put(currentTurn)

        val root = JSONObject()
        root.put("contents", contents)
        return root.toString()
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
        val bytes = stream.toByteArray()
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    // ---------------------------------------------------------------------
    // Raw HTTP POST via HttpURLConnection
    // ---------------------------------------------------------------------
    private fun postJson(urlString: String, jsonBody: String): String {
        val url = URL(urlString)
        val connection = url.openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.doOutput = true
            connection.connectTimeout = 30000
            connection.readTimeout = 60000

            OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(jsonBody)
                writer.flush()
            }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }

            if (code !in 200..299) {
                throw RuntimeException("HTTP $code: $responseText")
            }
            return responseText
        } finally {
            connection.disconnect()
        }
    }

    // ---------------------------------------------------------------------
    // Response parsing — supports both raw Gemini responses and proxies
    // that pass the Gemini JSON straight through.
    // ---------------------------------------------------------------------
    private fun extractReplyText(json: String): String {
        return try {
            val root = JSONObject(json)
            val candidates = root.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val content = candidates.getJSONObject(0).optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val sb = StringBuilder()
                    for (i in 0 until parts.length()) {
                        sb.append(parts.getJSONObject(i).optString("text", ""))
                    }
                    return sb.toString().ifBlank { "(No response text)" }
                }
            }
            // Fallback: some proxies wrap the reply as {"reply": "..."} or {"text": "..."}
            root.optString("reply").takeIf { it.isNotBlank() }
                ?: root.optString("text").takeIf { it.isNotBlank() }
                ?: "(Could not parse AI response)"
        } catch (e: Exception) {
            "(Error parsing response: ${e.message})"
        }
    }

    companion object {
        private const val TAG = "GeminiClient"
    }
}
