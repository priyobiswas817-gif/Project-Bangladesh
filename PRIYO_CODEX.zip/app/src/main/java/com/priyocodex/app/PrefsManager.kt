package com.priyocodex.app

import android.content.Context
import android.content.SharedPreferences

/**
 * Wraps SharedPreferences to persist the user's Gemini / Cloudflare proxy
 * configuration. Values are editable at any time from the Settings dialog.
 */
class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var setupDone: Boolean
        get() = prefs.getBoolean(KEY_SETUP_DONE, false)
        set(value) = prefs.edit().putBoolean(KEY_SETUP_DONE, value).apply()

    var proxyUrl: String
        get() = prefs.getString(KEY_PROXY_URL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_PROXY_URL, value).apply()

    var apiKey: String
        get() = prefs.getString(KEY_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_API_KEY, value).apply()

    var apiVersion: String
        get() = prefs.getString(KEY_API_VERSION, "v1beta") ?: "v1beta"
        set(value) = prefs.edit().putString(KEY_API_VERSION, value).apply()

    var model: String
        get() = prefs.getString(KEY_MODEL, "gemini-2.0-flash") ?: "gemini-2.0-flash"
        set(value) = prefs.edit().putString(KEY_MODEL, value).apply()

    fun saveAll(proxyUrl: String, apiKey: String, apiVersion: String, model: String) {
        prefs.edit()
            .putString(KEY_PROXY_URL, proxyUrl)
            .putString(KEY_API_KEY, apiKey)
            .putString(KEY_API_VERSION, apiVersion.ifBlank { "v1beta" })
            .putString(KEY_MODEL, model.ifBlank { "gemini-2.0-flash" })
            .putBoolean(KEY_SETUP_DONE, true)
            .apply()
    }

    /** True if we have enough info (proxy OR api key) to make a request. */
    fun isConfigured(): Boolean = proxyUrl.isNotBlank() || apiKey.isNotBlank()

    companion object {
        private const val PREFS_NAME = "priyo_codex_prefs"
        private const val KEY_SETUP_DONE = "setup_done"
        private const val KEY_PROXY_URL = "proxy_url"
        private const val KEY_API_KEY = "api_key"
        private const val KEY_API_VERSION = "api_version"
        private const val KEY_MODEL = "model"
    }
}
