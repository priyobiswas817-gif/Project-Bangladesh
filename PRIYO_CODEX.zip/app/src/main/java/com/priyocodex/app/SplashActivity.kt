package com.priyocodex.app

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    private val splashDelayMillis = 2200L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val logoGroup = findViewById<FrameLayout>(R.id.logoGroup)
        val welcomeText = findViewById<TextView>(R.id.txtWelcomeSplash)

        // Scale-up / fade-in animation for the logo
        val scaleFadeAnim = AnimationUtils.loadAnimation(this, R.anim.scale_fade_in)
        logoGroup.startAnimation(scaleFadeAnim)

        // Fade-up animation for the wordmark, slightly delayed
        val fadeInSlow = AnimationUtils.loadAnimation(this, R.anim.fade_in_slow)
        welcomeText.startAnimation(fadeInSlow)

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }, splashDelayMillis)
    }
}
