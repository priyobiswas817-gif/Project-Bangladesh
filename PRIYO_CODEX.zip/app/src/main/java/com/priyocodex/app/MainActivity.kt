package com.priyocodex.app

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var prefs: PrefsManager
    private lateinit var geminiClient: GeminiClient
    private lateinit var adapter: ChatAdapter
    private val messages = mutableListOf<ChatMessage>()

    private lateinit var recyclerChat: RecyclerView
    private lateinit var welcomeView: View
    private lateinit var editMessage: EditText
    private lateinit var btnSend: ImageButton
    private lateinit var btnAttach: ImageButton
    private lateinit var btnMic: ImageButton

    private var tts: TextToSpeech? = null
    private var pendingImageUri: Uri? = null
    private var pendingImageBitmap: Bitmap? = null

    // ---- Activity result launchers (image pick + voice input) ----
    private val imagePickerLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val uri = result.data?.data
                if (uri != null) {
                    pendingImageUri = uri
                    try {
                        contentResolver.openInputStream(uri)?.use { stream ->
                            pendingImageBitmap = BitmapFactory.decodeStream(stream)
                        }
                        Toast.makeText(this, "Image attached", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Toast.makeText(this, "Could not load image", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

    private val voiceInputLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val spokenResults =
                    result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                val spokenText = spokenResults?.firstOrNull()
                if (!spokenText.isNullOrBlank()) {
                    editMessage.setText(spokenText)
                    editMessage.setSelection(spokenText.length)
                }
            }
        }

    private val micPermissionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) launchVoiceInput() else
                Toast.makeText(this, "Microphone permission required", Toast.LENGTH_SHORT).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = PrefsManager(this)
        geminiClient = GeminiClient(prefs)
        tts = TextToSpeech(this, this)

        bindViews()
        setupRecycler()
        setupClickListeners()
        refreshWelcomeVisibility()

        // First-run setup: force the configuration dialog until proxy/key is set.
        if (!prefs.setupDone || !prefs.isConfigured()) {
            showSettingsDialog(forced = true)
        }
    }

    private fun bindViews() {
        recyclerChat = findViewById(R.id.recyclerChat)
        welcomeView = findViewById(R.id.welcomeView)
        editMessage = findViewById(R.id.editMessage)
        btnSend = findViewById(R.id.btnSend)
        btnAttach = findViewById(R.id.btnAttach)
        btnMic = findViewById(R.id.btnMic)
    }

    private fun setupRecycler() {
        adapter = ChatAdapter(messages) { text -> speak(text) }
        recyclerChat.layoutManager = LinearLayoutManager(this)
        recyclerChat.adapter = adapter
    }

    private fun setupClickListeners() {
        findViewById<ImageButton>(R.id.btnNewChat).setOnClickListener { clearChat() }
        findViewById<ImageButton>(R.id.btnClearChat).setOnClickListener { clearChat() }
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener { showSettingsDialog(forced = false) }

        btnAttach.setOnClickListener { openImagePicker() }
        btnMic.setOnClickListener { requestMicAndListen() }
        btnSend.setOnClickListener { onSendClicked() }
    }

    // ---------------------------------------------------------------------
    // Sending messages
    // ---------------------------------------------------------------------
    private fun onSendClicked() {
        val text = editMessage.text.toString().trim()
        if (text.isBlank() && pendingImageBitmap == null) return

        if (!prefs.isConfigured()) {
            Toast.makeText(this, "Please configure API key / proxy URL first", Toast.LENGTH_LONG).show()
            showSettingsDialog(forced = true)
            return
        }

        val userMsg = ChatMessage(
            text = text,
            isUser = true,
            imageUri = pendingImageUri?.toString()
        )
        adapter.addMessage(userMsg)
        recyclerChat.scrollToPosition(messages.size - 1)
        refreshWelcomeVisibility()

        val imageForRequest = pendingImageBitmap
        editMessage.setText("")
        pendingImageUri = null
        pendingImageBitmap = null

        geminiClient.sendMessage(
            userText = text,
            imageBitmap = imageForRequest,
            history = messages.dropLast(1),
            callback = object : GeminiClient.Callback {
                override fun onSuccess(reply: String) {
                    val botMsg = ChatMessage(text = reply, isUser = false)
                    adapter.addMessage(botMsg)
                    recyclerChat.scrollToPosition(messages.size - 1)
                    speak(reply)
                }

                override fun onError(message: String) {
                    val botMsg = ChatMessage(text = "⚠️ Error: $message", isUser = false)
                    adapter.addMessage(botMsg)
                    recyclerChat.scrollToPosition(messages.size - 1)
                }
            }
        )
    }

    private fun clearChat() {
        adapter.clearAll()
        refreshWelcomeVisibility()
    }

    private fun refreshWelcomeVisibility() {
        welcomeView.visibility = if (messages.isEmpty()) View.VISIBLE else View.GONE
        recyclerChat.visibility = if (messages.isEmpty()) View.GONE else View.VISIBLE
    }

    // ---------------------------------------------------------------------
    // Image attach
    // ---------------------------------------------------------------------
    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
        }
        imagePickerLauncher.launch(Intent.createChooser(intent, "Select Image"))
    }

    // ---------------------------------------------------------------------
    // Voice input (Speech-to-Text)
    // ---------------------------------------------------------------------
    private fun requestMicAndListen() {
        val granted = ContextCompat.checkSelfPermission(
            this, android.Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (granted) {
            launchVoiceInput()
        } else {
            micPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun launchVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your message…")
        }
        try {
            voiceInputLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Voice input not supported on this device", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------------
    // Text-to-Speech
    // ---------------------------------------------------------------------
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.getDefault()
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "PRIYO_CODEX_UTTERANCE")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    // ---------------------------------------------------------------------
    // Settings / first-run setup dialog
    // ---------------------------------------------------------------------
    private fun showSettingsDialog(forced: Boolean) {
        val view = layoutInflater.inflate(R.layout.dialog_settings, null)
        val editProxyUrl = view.findViewById<EditText>(R.id.editProxyUrl)
        val editApiKey = view.findViewById<EditText>(R.id.editApiKey)
        val editApiVersion = view.findViewById<EditText>(R.id.editApiVersion)
        val editModel = view.findViewById<EditText>(R.id.editModel)

        // Pre-fill with existing saved values (so editing anytime works).
        editProxyUrl.setText(prefs.proxyUrl)
        editApiKey.setText(prefs.apiKey)
        editApiVersion.setText(prefs.apiVersion)
        editModel.setText(prefs.model)

        val builder = AlertDialog.Builder(this)
            .setView(view)
            .setCancelable(!forced)
            .setPositiveButton(R.string.save, null) // set below to prevent auto-dismiss on invalid input

        if (!forced) {
            builder.setNegativeButton(R.string.cancel, null)
        }

        val dialog = builder.create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val proxyUrl = editProxyUrl.text.toString().trim()
                val apiKey = editApiKey.text.toString().trim()
                val apiVersion = editApiVersion.text.toString().trim()
                val model = editModel.text.toString().trim()

                if (proxyUrl.isBlank() && apiKey.isBlank()) {
                    Toast.makeText(
                        this,
                        "Enter either a Proxy URL or an API Key",
                        Toast.LENGTH_SHORT
                    ).show()
                    return@setOnClickListener
                }

                prefs.saveAll(proxyUrl, apiKey, apiVersion, model)
                Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
        }
        dialog.show()
    }
}
